<?php exit(); ?>a:3:{s:5:"value";a:2:{s:13:"last_modified";i:1491377799;s:3:"css";s:56:"
    #im_48{ z-index:65535; position:absolute;left:0 ;}
";}s:3:"ttl";i:0;s:8:"dateline";i:1491377799;}